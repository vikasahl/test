<?php
namespace Civi\CCase\Exception;

/**
 * Class MultipleActivityException
 *
 * @package Civi\CCase\Exception
 */
class MultipleActivityException extends \CRM_Core_Exception {

}
