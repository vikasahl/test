<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.6.10',
                'cms'      => 'Drupal',
                'revision' => '3a0725b2d0' );
}

